import { Injectable, ServiceUnavailableException } from '@nestjs/common';

export interface GeocodedLocation {
  city: string;
  latitude: number;
  longitude: number;
}

interface AdresseResponse {
  features?: {
    geometry: { coordinates: [number, number] };
    properties: { city?: string; name?: string };
  }[];
}

const ADRESSE_URL = 'https://api-adresse.data.gouv.fr/search/';

/** Convertit une ville + un code postal français en coordonnées (API Adresse, sans clé). */
@Injectable()
export class GeocodingService {
  async geocode(
    city: string,
    postalCode: string,
  ): Promise<GeocodedLocation | null> {
    const url = new URL(ADRESSE_URL);
    url.searchParams.set('q', city);
    url.searchParams.set('postcode', postalCode);
    url.searchParams.set('type', 'municipality');
    url.searchParams.set('limit', '1');

    let response: Response;
    try {
      response = await fetch(url, { signal: AbortSignal.timeout(8000) });
    } catch {
      throw new ServiceUnavailableException(
        'Le service de localisation est indisponible, réessayez plus tard.',
      );
    }
    if (!response.ok) {
      throw new ServiceUnavailableException(
        'Le service de localisation est indisponible, réessayez plus tard.',
      );
    }

    const data = (await response.json()) as AdresseResponse;
    const feature = data.features?.[0];
    if (!feature) return null;

    const [longitude, latitude] = feature.geometry.coordinates;
    return {
      city: feature.properties.city ?? feature.properties.name ?? city,
      latitude,
      longitude,
    };
  }
}
