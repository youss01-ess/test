import { ServiceUnavailableException } from '@nestjs/common';
import { GeocodingService } from './geocoding.service';

describe('GeocodingService', () => {
  const service = new GeocodingService();
  const fetchMock = jest.fn();

  beforeEach(() => {
    fetchMock.mockReset();
    global.fetch = fetchMock as unknown as typeof fetch;
  });

  it('retourne les coordonnées de la commune trouvée', async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      json: () =>
        Promise.resolve({
          features: [
            {
              geometry: { coordinates: [3.0573, 50.6292] },
              properties: { city: 'Lille' },
            },
          ],
        }),
    });

    const result = await service.geocode('lille', '59000');

    expect(result).toEqual({ city: 'Lille', latitude: 50.6292, longitude: 3.0573 });
    const called = String(fetchMock.mock.calls[0][0]);
    expect(called).toContain('postcode=59000');
    expect(called).toContain('type=municipality');
  });

  it('retourne null si aucune commune ne correspond', async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      json: () => Promise.resolve({ features: [] }),
    });

    expect(await service.geocode('Nullepart', '00000')).toBeNull();
  });

  it('lève une 503 si le service est injoignable', async () => {
    fetchMock.mockRejectedValue(new Error('réseau'));

    await expect(service.geocode('Lille', '59000')).rejects.toBeInstanceOf(
      ServiceUnavailableException,
    );
  });

  it('lève une 503 si le service répond en erreur', async () => {
    fetchMock.mockResolvedValue({ ok: false });

    await expect(service.geocode('Lille', '59000')).rejects.toBeInstanceOf(
      ServiceUnavailableException,
    );
  });
});
