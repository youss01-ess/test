import { Transform } from 'class-transformer';
import {
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  Max,
  MaxLength,
  Min,
} from 'class-validator';

const trim = ({ value }: { value: unknown }) =>
  typeof value === 'string' ? value.trim() : value;

// Une chaîne vide devient null : c'est la façon d'effacer un champ optionnel.
const trimOrNull = ({ value }: { value: unknown }) => {
  if (typeof value !== 'string') return value;
  const trimmed = value.trim();
  return trimmed === '' ? null : trimmed;
};

export const AVATAR_MAX_LENGTH = 150_000;

export class UpdateProfileDto {
  @IsOptional()
  @Transform(trim)
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  firstName?: string;

  @IsOptional()
  @Transform(trim)
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  lastName?: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  @Max(120)
  age?: number;

  /** Ville (avec le code postal). `null` ou chaîne vide : efface l'adresse. */
  @IsOptional()
  @Transform(trimOrNull)
  @IsString()
  @MaxLength(100)
  city?: string | null;

  /** Code postal français à 5 chiffres. `null` ou chaîne vide : efface l'adresse. */
  @IsOptional()
  @Transform(trimOrNull)
  @Matches(/^\d{5}$/, { message: 'Le code postal doit contenir 5 chiffres' })
  postalCode?: string | null;

  /** Photo de profil en data URL (jpeg, png ou webp). `null` : supprime la photo. */
  @IsOptional()
  @Matches(/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/, {
    message: 'La photo doit être une image jpeg, png ou webp valide',
  })
  @MaxLength(AVATAR_MAX_LENGTH, { message: 'La photo est trop volumineuse' })
  avatarUrl?: string | null;
}
