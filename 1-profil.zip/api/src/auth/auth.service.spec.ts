import {
  ConflictException,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Test, TestingModule } from '@nestjs/testing';
import { Prisma, User } from '@prisma/client';
import * as argon2 from '@node-rs/argon2';
import { UsersService } from '../users/users.service';
import { AuthService } from './auth.service';

const mockUser: User = {
  id: 'user-1',
  email: 'test@mail.com',
  passwordHash: '$argon2id$...',
  firstName: 'Test',
  lastName: 'User',
  age: 25,
  birthDate: null,
  sex: null,
  latitude: null,
  longitude: null,
  city: null,
  postalCode: null,
  avatarUrl: null,
  createdAt: new Date(),
  updatedAt: new Date(),
};

describe('AuthService', () => {
  let authService: AuthService;
  let usersService: {
    findByEmail: jest.Mock;
    findById: jest.Mock;
    create: jest.Mock;
  };
  let jwtService: {
    signAsync: jest.Mock;
  };

  beforeEach(async () => {
    usersService = {
      findByEmail: jest.fn(),
      findById: jest.fn(),
      create: jest.fn(),
    };
    jwtService = {
      signAsync: jest.fn().mockResolvedValue('jwt-token-123'),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: UsersService, useValue: usersService },
        { provide: JwtService, useValue: jwtService },
      ],
    }).compile();

    authService = module.get<AuthService>(AuthService);
  });

  describe('register', () => {
    it('crée un utilisateur et retourne un profil sans mot de passe', async () => {
      usersService.findByEmail.mockResolvedValue(null);
      usersService.create.mockResolvedValue(mockUser);

      const result = await authService.register({
        email: 'test@mail.com',
        password: 'Password123!',
        firstName: 'Test',
        lastName: 'User',
        age: 25,
      });

      expect(result).toMatchObject({
        id: 'user-1',
        email: 'test@mail.com',
        firstName: 'Test',
      });
      expect(result).not.toHaveProperty('passwordHash');
    });

    it('lève ConflictException si l’email est déjà utilisé', async () => {
      usersService.findByEmail.mockResolvedValue(mockUser);

      await expect(
        authService.register({
          email: 'test@mail.com',
          password: 'Password123!',
          firstName: 'Test',
          lastName: 'User',
          age: 25,
        }),
      ).rejects.toThrow(ConflictException);
    });

    it('gère l’erreur Prisma P2002 (conflit de clé unique) et lève ConflictException', async () => {
      usersService.findByEmail.mockResolvedValue(null);
      const prismaError = new Prisma.PrismaClientKnownRequestError('Doublon', {
        code: 'P2002',
        clientVersion: '6.0.0',
      });
      usersService.create.mockRejectedValue(prismaError);

      await expect(
        authService.register({
          email: 'test@mail.com',
          password: 'Password123!',
          firstName: 'Test',
          lastName: 'User',
          age: 25,
        }),
      ).rejects.toThrow(ConflictException);
    });

    it('relance une erreur imprévue lors de la création', async () => {
      usersService.findByEmail.mockResolvedValue(null);
      usersService.create.mockRejectedValue(new Error('Erreur base de données'));

      await expect(
        authService.register({
          email: 'test@mail.com',
          password: 'Password123!',
          firstName: 'Test',
          lastName: 'User',
          age: 25,
        }),
      ).rejects.toThrow('Erreur base de données');
    });
  });

  describe('login', () => {
    it('génère un token JWT et renvoie le profil en cas de mot de passe valide', async () => {
      const hash = await argon2.hash('Secret123');
      const userWithRealHash = { ...mockUser, passwordHash: hash };
      usersService.findByEmail.mockResolvedValue(userWithRealHash);

      const result = await authService.login({
        email: 'test@mail.com',
        password: 'Secret123',
      });

      expect(result.accessToken).toBe('jwt-token-123');
      expect(result.user.email).toBe('test@mail.com');
      expect(result.user).not.toHaveProperty('passwordHash');
    });

    it('lève UnauthorizedException si l’utilisateur est introuvable', async () => {
      usersService.findByEmail.mockResolvedValue(null);

      await expect(
        authService.login({
          email: 'inconnu@mail.com',
          password: 'Secret123',
        }),
      ).rejects.toThrow(UnauthorizedException);
    });

    it('lève UnauthorizedException si le mot de passe est erroné', async () => {
      const hash = await argon2.hash('VraiMotDePasse');
      usersService.findByEmail.mockResolvedValue({
        ...mockUser,
        passwordHash: hash,
      });

      await expect(
        authService.login({
          email: 'test@mail.com',
          password: 'FauxMotDePasse',
        }),
      ).rejects.toThrow(UnauthorizedException);
    });
  });

  describe('getProfile', () => {
    it('retourne le profil de l’utilisateur sans passwordHash', async () => {
      usersService.findById.mockResolvedValue(mockUser);

      const result = await authService.getProfile('user-1');

      expect(result.id).toBe('user-1');
      expect(result).not.toHaveProperty('passwordHash');
    });

    it('lève UnauthorizedException si l’utilisateur n’existe plus', async () => {
      usersService.findById.mockResolvedValue(null);

      await expect(authService.getProfile('user-supprime')).rejects.toThrow(
        UnauthorizedException,
      );
    });
  });
});
