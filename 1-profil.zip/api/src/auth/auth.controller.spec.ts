import { INestApplication, ValidationPipe } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { Test } from '@nestjs/testing';
import { Prisma, User } from '@prisma/client';
import { randomUUID } from 'crypto';
import request from 'supertest';
import { UsersService } from '../users/users.service';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';

class FakeUsersService {
  users: User[] = [];

  findByEmail(email: string): Promise<User | null> {
    return Promise.resolve(this.users.find((u) => u.email === email) ?? null);
  }

  findById(id: string): Promise<User | null> {
    return Promise.resolve(this.users.find((u) => u.id === id) ?? null);
  }

  create(data: Prisma.UserCreateInput): Promise<User> {
    const user: User = {
      id: randomUUID(),
      email: data.email,
      passwordHash: data.passwordHash,
      firstName: data.firstName,
      lastName: data.lastName,
      age: data.age,
      birthDate: null,
      sex: null,
      latitude: null,
      longitude: null,
      city: null,
      postalCode: null,
      avatarUrl: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.push(user);
    return Promise.resolve(user);
  }
}

const validUser = {
  email: 'test@mail.com',
  password: 'motdepasse123',
  firstName: 'Test',
  lastName: 'User',
  age: 25,
};

describe('AuthController', () => {
  let app: INestApplication;
  let fakeUsers: FakeUsersService;

  beforeEach(async () => {
    fakeUsers = new FakeUsersService();

    const moduleRef = await Test.createTestingModule({
      imports: [
        JwtModule.register({
          secret: 'secret-de-test',
          signOptions: { expiresIn: 3600 },
        }),
      ],
      controllers: [AuthController],
      providers: [
        AuthService,
        JwtAuthGuard,
        { provide: UsersService, useValue: fakeUsers },
      ],
    }).compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();
  });

  afterEach(async () => {
    await app.close();
  });

  const http = () => request(app.getHttpServer());

  describe('POST /auth/register', () => {
    it('crée un compte et ne renvoie pas le mot de passe (201)', async () => {
      const res = await http()
        .post('/auth/register')
        .send({ ...validUser, email: 'Test@Mail.com' })
        .expect(201);

      expect(res.body).toMatchObject({
        email: 'test@mail.com',
        firstName: 'Test',
        lastName: 'User',
        age: 25,
      });
      expect(res.body).not.toHaveProperty('passwordHash');
      expect(res.body).not.toHaveProperty('password');
    });

    it('stocke un hash argon2 et non le mot de passe en clair', async () => {
      await http().post('/auth/register').send(validUser).expect(201);

      expect(fakeUsers.users[0].passwordHash).toMatch(/^\$argon2/);
      expect(fakeUsers.users[0].passwordHash).not.toContain(validUser.password);
    });

    it('refuse un email déjà utilisé (409)', async () => {
      await http().post('/auth/register').send(validUser).expect(201);
      await http().post('/auth/register').send(validUser).expect(409);
    });

    it('refuse un email invalide (400)', async () => {
      await http()
        .post('/auth/register')
        .send({ ...validUser, email: 'pas-un-email' })
        .expect(400);
    });

    it('refuse un mot de passe trop court (400)', async () => {
      await http()
        .post('/auth/register')
        .send({ ...validUser, password: '123' })
        .expect(400);
    });

    it('refuse un âge incohérent (400)', async () => {
      await http()
        .post('/auth/register')
        .send({ ...validUser, age: 250 })
        .expect(400);
    });

    it('refuse sans prénom (400)', async () => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { firstName, ...withoutFirstName } = validUser;
      await http().post('/auth/register').send(withoutFirstName).expect(400);
    });

    it('refuse sans nom (400)', async () => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { lastName, ...withoutLastName } = validUser;
      await http().post('/auth/register').send(withoutLastName).expect(400);
    });

    it('ignore les champs inconnus', async () => {
      const res = await http()
        .post('/auth/register')
        .send({ ...validUser, role: 'admin' })
        .expect(201);

      expect(res.body).not.toHaveProperty('role');
    });
  });

  describe('POST /auth/login', () => {
    beforeEach(async () => {
      await http().post('/auth/register').send(validUser).expect(201);
    });

    it('renvoie un jeton avec de bons identifiants (200)', async () => {
      const res = await http()
        .post('/auth/login')
        .send({ email: validUser.email, password: validUser.password })
        .expect(200);

      expect(typeof res.body.accessToken).toBe('string');
      expect(res.body.user.email).toBe(validUser.email);
      expect(res.body.user).not.toHaveProperty('passwordHash');
    });

    it('accepte un email avec des majuscules (200)', async () => {
      await http()
        .post('/auth/login')
        .send({ email: 'TEST@MAIL.COM', password: validUser.password })
        .expect(200);
    });

    it('refuse un mauvais mot de passe (401)', async () => {
      await http()
        .post('/auth/login')
        .send({ email: validUser.email, password: 'faux12345' })
        .expect(401);
    });

    it('renvoie le même message pour un email inconnu (401)', async () => {
      const wrongPassword = await http()
        .post('/auth/login')
        .send({ email: validUser.email, password: 'faux12345' });
      const unknownEmail = await http()
        .post('/auth/login')
        .send({ email: 'inconnu@mail.com', password: 'motdepasse123' })
        .expect(401);

      expect(unknownEmail.body.message).toBe(wrongPassword.body.message);
    });

    it('refuse un email invalide (400)', async () => {
      await http()
        .post('/auth/login')
        .send({ email: 'abc', password: 'x' })
        .expect(400);
    });
  });

  describe('GET /auth/me', () => {
    let token: string;

    beforeEach(async () => {
      await http().post('/auth/register').send(validUser).expect(201);
      const res = await http()
        .post('/auth/login')
        .send({ email: validUser.email, password: validUser.password })
        .expect(200);
      token = res.body.accessToken as string;
    });

    it('refuse sans jeton (401)', async () => {
      await http().get('/auth/me').expect(401);
    });

    it('refuse un faux jeton (401)', async () => {
      await http()
        .get('/auth/me')
        .set('Authorization', 'Bearer n-importe-quoi')
        .expect(401);
    });

    it('refuse un jeton modifié (401)', async () => {
      await http()
        .get('/auth/me')
        .set('Authorization', `Bearer ${token}x`)
        .expect(401);
    });

    it('renvoie le profil avec un jeton valide (200)', async () => {
      const res = await http()
        .get('/auth/me')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(res.body.email).toBe(validUser.email);
      expect(res.body).not.toHaveProperty('passwordHash');
    });

    it('refuse un jeton dont le compte a été supprimé (401)', async () => {
      fakeUsers.users = [];

      await http()
        .get('/auth/me')
        .set('Authorization', `Bearer ${token}`)
        .expect(401);
    });
  });
});