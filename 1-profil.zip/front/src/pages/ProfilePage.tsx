import { useRef, useState, type FormEvent } from 'react';
import { Link } from 'react-router';
import { useAuth } from '../auth/AuthContext';
import Alert from '../components/Alert';
import Avatar from '../components/Avatar';
import Badge from '../components/Badge';
import Button from '../components/Button';
import Card from '../components/Card';
import FormField from '../components/FormField';
import Layout from '../components/Layout';
import { resizeImageToDataUrl } from '../utils/image';

function useFormAction() {
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function run(action: () => Promise<void>, successMessage: string) {
    setError(null);
    setSuccess(null);
    setPending(true);
    try {
      await action();
      setSuccess(successMessage);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue');
    } finally {
      setPending(false);
    }
  }

  return { error, success, pending, run };
}

function PersonalInfoSection() {
  const { user, updateProfile } = useAuth();
  const { error, success, pending, run } = useFormAction();
  const [firstName, setFirstName] = useState(user?.firstName ?? '');
  const [lastName, setLastName] = useState(user?.lastName ?? '');
  const [age, setAge] = useState(String(user?.age ?? ''));

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    void run(
      () => updateProfile({ firstName, lastName, age: Number(age) }),
      'Vos informations ont été mises à jour.',
    );
  }

  return (
    <Card className="mt-6 p-6 sm:p-8">
      <h2 className="text-xl font-bold text-slate-950">
        Informations personnelles
      </h2>
      <p className="mt-1 text-sm text-slate-600">
        Votre prénom, votre nom et votre âge.
      </p>

      <form className="mt-6 space-y-5" onSubmit={handleSubmit}>
        {error && <Alert variant="error">{error}</Alert>}
        {success && <Alert variant="success">{success}</Alert>}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <FormField
            autoComplete="given-name"
            id="profile-firstname"
            label="Prénom"
            onChange={(e) => setFirstName(e.target.value)}
            required
            type="text"
            value={firstName}
          />
          <FormField
            autoComplete="family-name"
            id="profile-lastname"
            label="Nom"
            onChange={(e) => setLastName(e.target.value)}
            required
            type="text"
            value={lastName}
          />
        </div>

        <FormField
          id="profile-age"
          label="Âge"
          max={120}
          min={0}
          onChange={(e) => setAge(e.target.value)}
          required
          type="number"
          value={age}
        />

        <Button disabled={pending} type="submit">
          {pending ? 'Enregistrement…' : 'Enregistrer'}
        </Button>
      </form>
    </Card>
  );
}

function AvatarSection() {
  const { user, updateProfile } = useAuth();
  const { error, success, pending, run } = useFormAction();
  const inputRef = useRef<HTMLInputElement>(null);

  if (!user) return null;

  function handleFile(file: File | undefined) {
    if (!file) return;
    void run(async () => {
      const avatarUrl = await resizeImageToDataUrl(file);
      await updateProfile({ avatarUrl });
    }, 'Votre photo a été mise à jour.');
    if (inputRef.current) inputRef.current.value = '';
  }

  return (
    <Card className="mt-6 p-6 sm:p-8">
      <h2 className="text-xl font-bold text-slate-950">Photo de profil</h2>
      <p className="mt-1 text-sm text-slate-600">
        Facultatif : personnalisez votre espace. L'image est recadrée et
        réduite automatiquement.
      </p>

      <div className="mt-6 space-y-5">
        {error && <Alert variant="error">{error}</Alert>}
        {success && <Alert variant="success">{success}</Alert>}

        <div className="flex flex-wrap items-center gap-4">
          <Avatar
            className="h-20 w-20 text-2xl"
            firstName={user.firstName}
            lastName={user.lastName}
            src={user.avatarUrl}
          />
          <input
            accept="image/jpeg,image/png,image/webp"
            aria-label="Choisir une photo de profil"
            className="hidden"
            onChange={(e) => handleFile(e.target.files?.[0])}
            ref={inputRef}
            type="file"
          />
          <Button
            disabled={pending}
            onClick={() => inputRef.current?.click()}
            variant="secondary"
          >
            {user.avatarUrl ? 'Changer la photo' : 'Ajouter une photo'}
          </Button>
          {user.avatarUrl && (
            <Button
              disabled={pending}
              onClick={() =>
                void run(
                  () => updateProfile({ avatarUrl: null }),
                  'Votre photo a été supprimée.',
                )
              }
              variant="outline"
            >
              Supprimer
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}

function LocationSection() {
  const { user, updateProfile } = useAuth();
  const { error, success, pending, run } = useFormAction();
  const [postalCode, setPostalCode] = useState(user?.postalCode ?? '');
  const [city, setCity] = useState(user?.city ?? '');

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    void run(
      () => updateProfile({ city, postalCode }),
      city || postalCode
        ? 'Votre localisation a été enregistrée.'
        : 'Votre localisation a été supprimée.',
    );
  }

  async function handleClear() {
    await run(
      () => updateProfile({ city: null, postalCode: null }),
      'Votre localisation a été supprimée.',
    );
    setCity('');
    setPostalCode('');
  }

  return (
    <Card className="mt-6 p-6 sm:p-8">
      <h2 className="text-xl font-bold text-slate-950">Localisation</h2>
      <p className="mt-1 text-sm text-slate-600">
        Facultatif. Votre ville et votre code postal servent uniquement à
        suggérer des vétérinaires proches de chez vous. Nous ne gardons pas
        votre adresse exacte, seulement la position de votre commune.
      </p>

      <form className="mt-6 space-y-5" onSubmit={handleSubmit}>
        {error && <Alert variant="error">{error}</Alert>}
        {success && <Alert variant="success">{success}</Alert>}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <FormField
            autoComplete="postal-code"
            id="profile-postalcode"
            inputMode="numeric"
            label="Code postal"
            maxLength={5}
            onChange={(e) => setPostalCode(e.target.value)}
            pattern="\d{5}"
            placeholder="59000"
            title="5 chiffres"
            type="text"
            value={postalCode}
          />
          <div className="sm:col-span-2">
            <FormField
              autoComplete="address-level2"
              id="profile-city"
              label="Ville"
              onChange={(e) => setCity(e.target.value)}
              placeholder="Lille"
              type="text"
              value={city}
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          <Button disabled={pending} type="submit">
            {pending ? 'Enregistrement…' : 'Enregistrer'}
          </Button>
          {user?.city && (
            <Button
              disabled={pending}
              onClick={() => void handleClear()}
              variant="outline"
            >
              Supprimer ma localisation
            </Button>
          )}
        </div>

        {user?.city && (
          <p className="text-sm text-slate-600">
            Position actuelle : {user.postalCode} {user.city}.
          </p>
        )}
      </form>
    </Card>
  );
}

function EmailSection() {
  const { user, updateEmail } = useAuth();
  const { error, success, pending, run } = useFormAction();
  const [email, setEmail] = useState(user?.email ?? '');
  const [currentPassword, setCurrentPassword] = useState('');

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    void run(async () => {
      await updateEmail(email, currentPassword);
      setCurrentPassword('');
    }, 'Votre adresse email a été mise à jour.');
  }

  return (
    <Card className="mt-6 p-6 sm:p-8">
      <h2 className="text-xl font-bold text-slate-950">Adresse email</h2>
      <p className="mt-1 text-sm text-slate-600">
        Pour la modifier, confirmez votre mot de passe actuel.
      </p>

      <form className="mt-6 space-y-5" onSubmit={handleSubmit}>
        {error && <Alert variant="error">{error}</Alert>}
        {success && <Alert variant="success">{success}</Alert>}

        <FormField
          autoComplete="email"
          id="profile-email"
          label="Nouvelle adresse email"
          onChange={(e) => setEmail(e.target.value)}
          required
          type="email"
          value={email}
        />
        <FormField
          autoComplete="current-password"
          id="profile-email-password"
          label="Mot de passe actuel"
          onChange={(e) => setCurrentPassword(e.target.value)}
          required
          type="password"
          value={currentPassword}
        />

        <Button disabled={pending} type="submit">
          {pending ? 'Enregistrement…' : "Changer l'email"}
        </Button>
      </form>
    </Card>
  );
}

function PasswordSection() {
  const { changePassword } = useAuth();
  const { error, success, pending, run } = useFormAction();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    void run(async () => {
      if (newPassword !== confirmation) {
        throw new Error('Les deux mots de passe ne correspondent pas');
      }
      await changePassword(currentPassword, newPassword);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmation('');
    }, 'Votre mot de passe a été modifié.');
  }

  return (
    <Card className="mt-6 p-6 sm:p-8">
      <h2 className="text-xl font-bold text-slate-950">Mot de passe</h2>
      <p className="mt-1 text-sm text-slate-600">
        Choisissez un nouveau mot de passe d'au moins 8 caractères.
      </p>

      <form className="mt-6 space-y-5" onSubmit={handleSubmit}>
        {error && <Alert variant="error">{error}</Alert>}
        {success && <Alert variant="success">{success}</Alert>}

        <FormField
          autoComplete="current-password"
          id="profile-current-password"
          label="Mot de passe actuel"
          onChange={(e) => setCurrentPassword(e.target.value)}
          required
          type="password"
          value={currentPassword}
        />
        <FormField
          autoComplete="new-password"
          id="profile-new-password"
          label="Nouveau mot de passe"
          minLength={8}
          onChange={(e) => setNewPassword(e.target.value)}
          placeholder="Au moins 8 caractères"
          required
          type="password"
          value={newPassword}
        />
        <FormField
          autoComplete="new-password"
          id="profile-confirm-password"
          label="Confirmer le nouveau mot de passe"
          minLength={8}
          onChange={(e) => setConfirmation(e.target.value)}
          required
          type="password"
          value={confirmation}
        />

        <Button disabled={pending} type="submit">
          {pending ? 'Enregistrement…' : 'Changer le mot de passe'}
        </Button>
      </form>
    </Card>
  );
}

export default function ProfilePage() {
  const { user } = useAuth();

  if (!user) return null;

  const memberSince = new Date(user.createdAt).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <Layout>
      <main className="mx-auto max-w-3xl px-5 py-12 sm:px-8 lg:py-20">
        <Link
          className="text-sm font-semibold text-emerald-700 transition hover:text-emerald-800"
          to="/"
        >
          ← Retour à l'accueil
        </Link>

        <div className="mt-6">
          <p className="text-sm font-semibold uppercase tracking-wide text-emerald-700">
            Mon espace
          </p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">
            Mon profil
          </h1>
          <p className="mt-3 max-w-2xl text-slate-600">
            Consultez et modifiez vos informations personnelles.
          </p>
        </div>

        <Card className="mt-8 p-6 sm:p-8">
          <div className="flex items-center gap-4">
            <Avatar
              firstName={user.firstName}
              lastName={user.lastName}
              src={user.avatarUrl}
            />
            <div className="min-w-0">
              <p className="truncate text-xl font-bold text-slate-900">
                {user.firstName} {user.lastName}
              </p>
              <p className="truncate text-sm text-slate-600">{user.email}</p>
              <div className="mt-2">
                <Badge>Membre depuis le {memberSince}</Badge>
              </div>
            </div>
          </div>
        </Card>

        <PersonalInfoSection />
        <AvatarSection />
        <LocationSection />
        <EmailSection />
        <PasswordSection />
      </main>
    </Layout>
  );
}