type AvatarProps = {
  firstName: string;
  lastName: string;
  src?: string | null;
  className?: string;
};

export default function Avatar({
  firstName,
  lastName,
  src,
  className = 'h-16 w-16 text-xl',
}: AvatarProps) {
  const initials =
    `${firstName[0] ?? ''}${lastName[0] ?? ''}`.toUpperCase();

  if (src) {
    return (
      <img
        alt={`Photo de ${firstName} ${lastName}`}
        className={`shrink-0 rounded-2xl object-cover ${className}`}
        src={src}
      />
    );
  }

  return (
    <div
      aria-hidden="true"
      className={`flex shrink-0 items-center justify-center rounded-2xl bg-emerald-100 font-bold text-emerald-700 ${className}`}
    >
      {initials}
    </div>
  );
}
