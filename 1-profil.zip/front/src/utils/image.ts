const MAX_FILE_BYTES = 8 * 1024 * 1024;
const MAX_DATA_URL_LENGTH = 140_000; // reste sous la limite de 150 000 de l'API

/**
 * Recadre l'image au carré, la réduit à `size` px et la compresse en JPEG.
 * Le résultat est une data URL légère, stockée telle quelle côté serveur.
 */
export async function resizeImageToDataUrl(
  file: File,
  size = 256,
): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Le fichier choisi n’est pas une image.');
  }
  if (file.size > MAX_FILE_BYTES) {
    throw new Error('L’image est trop lourde (8 Mo maximum).');
  }

  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new Error('Impossible de lire cette image.');
  }

  const side = Math.min(bitmap.width, bitmap.height);
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Impossible de traiter cette image.');

  context.drawImage(
    bitmap,
    (bitmap.width - side) / 2,
    (bitmap.height - side) / 2,
    side,
    side,
    0,
    0,
    size,
    size,
  );
  bitmap.close();

  for (const quality of [0.85, 0.7, 0.55, 0.4]) {
    const dataUrl = canvas.toDataURL('image/jpeg', quality);
    if (dataUrl.length <= MAX_DATA_URL_LENGTH) return dataUrl;
  }
  throw new Error('L’image est trop détaillée, choisissez-en une autre.');
}
