import {
  BadRequestException,
  Injectable,
  ServiceUnavailableException,
  UnauthorizedException,
} from '@nestjs/common';
import { UsersService } from '../users/users.service';
import { DEFAULT_RADIUS_KM } from './dto/nearby-vets-query.dto';

export interface Vet {
  id: string;
  name: string;
  address: string | null;
  phone: string | null;
  website: string | null;
  latitude: number;
  longitude: number;
  distanceKm: number;
}

export interface NearbyVetsResponse {
  center: { city: string; latitude: number; longitude: number };
  radiusKm: number;
  vets: Vet[];
}

interface OverpassElement {
  type: string;
  id: number;
  lat?: number;
  lon?: number;
  center?: { lat: number; lon: number };
  tags?: Record<string, string>;
}

const OVERPASS_URL = 'https://overpass-api.de/api/interpreter';
const MAX_RESULTS = 30;
const CACHE_TTL_MS = 60 * 60 * 1000;

/** Distance à vol d'oiseau en km (formule de haversine). */
export function distanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const a =
    Math.sin(toRad(lat2 - lat1) / 2) ** 2 +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(toRad(lon2 - lon1) / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(a));
}

/** Vétérinaires proches de l'adresse du profil, d'après OpenStreetMap (Overpass). */
@Injectable()
export class VetsService {
  private readonly cache = new Map<
    string,
    { timestamp: number; vets: Vet[] }
  >();

  constructor(private readonly usersService: UsersService) {}

  async findNearby(
    userId: string,
    radiusKm: number = DEFAULT_RADIUS_KM,
  ): Promise<NearbyVetsResponse> {
    const user = await this.usersService.findById(userId);
    if (!user) {
      throw new UnauthorizedException('Utilisateur introuvable');
    }
    if (user.latitude === null || user.longitude === null || !user.city) {
      throw new BadRequestException(
        'Renseignez votre ville et votre code postal dans votre profil pour trouver des vétérinaires proches.',
      );
    }

    const { latitude, longitude } = user;
    const vets = await this.search(latitude, longitude, radiusKm);

    return {
      center: { city: user.city, latitude, longitude },
      radiusKm,
      vets,
    };
  }

  private async search(
    latitude: number,
    longitude: number,
    radiusKm: number,
  ): Promise<Vet[]> {
    const key = `${latitude.toFixed(3)}:${longitude.toFixed(3)}:${radiusKm}`;
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
      return cached.vets;
    }

    const query = `[out:json][timeout:20];nwr["amenity"="veterinary"](around:${radiusKm * 1000},${latitude},${longitude});out center tags;`;

    let response: Response;
    try {
      response = await fetch(OVERPASS_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': 'HandyVet/0.1 (projet universitaire)',
        },
        body: new URLSearchParams({ data: query }),
        signal: AbortSignal.timeout(20000),
      });
    } catch {
      throw new ServiceUnavailableException(
        'La recherche de vétérinaires est indisponible, réessayez plus tard.',
      );
    }
    if (!response.ok) {
      throw new ServiceUnavailableException(
        'La recherche de vétérinaires est indisponible, réessayez plus tard.',
      );
    }

    const data = (await response.json()) as { elements?: OverpassElement[] };
    const vets = (data.elements ?? [])
      .map((element) => this.toVet(element, latitude, longitude))
      .filter((vet): vet is Vet => vet !== null)
      .sort((a, b) => a.distanceKm - b.distanceKm)
      .slice(0, MAX_RESULTS);

    this.cache.set(key, { timestamp: Date.now(), vets });
    return vets;
  }

  private toVet(
    element: OverpassElement,
    originLat: number,
    originLon: number,
  ): Vet | null {
    const lat = element.lat ?? element.center?.lat;
    const lon = element.lon ?? element.center?.lon;
    if (lat === undefined || lon === undefined) return null;

    const tags = element.tags ?? {};
    const street = [tags['addr:housenumber'], tags['addr:street']]
      .filter(Boolean)
      .join(' ');
    const town = [tags['addr:postcode'], tags['addr:city']]
      .filter(Boolean)
      .join(' ');
    const address = [street, town].filter(Boolean).join(', ');

    return {
      id: `${element.type}/${element.id}`,
      name: tags.name ?? 'Cabinet vétérinaire',
      address: address || null,
      phone: tags.phone ?? tags['contact:phone'] ?? null,
      website: this.safeUrl(tags.website ?? tags['contact:website']),
      latitude: lat,
      longitude: lon,
      distanceKm: Math.round(distanceKm(originLat, originLon, lat, lon) * 10) / 10,
    };
  }

  /** Les données OSM sont saisies par des contributeurs : on n'accepte que http(s). */
  private safeUrl(value?: string): string | null {
    if (!value) return null;
    const candidate = /^https?:\/\//i.test(value) ? value : `https://${value}`;
    try {
      const url = new URL(candidate);
      return url.protocol === 'http:' || url.protocol === 'https:'
        ? url.toString()
        : null;
    } catch {
      return null;
    }
  }
}
