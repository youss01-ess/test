import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { UsersModule } from '../users/users.module';
import { VetsController } from './vets.controller';
import { VetsService } from './vets.service';

@Module({
  imports: [AuthModule, UsersModule],
  controllers: [VetsController],
  providers: [VetsService],
})
export class VetsModule {}
