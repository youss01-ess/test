import { INestApplication, ValidationPipe } from '@nestjs/common';
import { JwtModule, JwtService } from '@nestjs/jwt';
import { Test } from '@nestjs/testing';
import { User } from '@prisma/client';
import request from 'supertest';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { UsersService } from '../users/users.service';
import { VetsController } from './vets.controller';
import { distanceKm, VetsService } from './vets.service';

const LILLE = { latitude: 50.6292, longitude: 3.0573 };

function makeUser(overrides: Partial<User> = {}): User {
  return {
    id: 'user-1',
    email: 'test@mail.com',
    passwordHash: 'hash',
    firstName: 'Test',
    lastName: 'User',
    age: 25,
    birthDate: null,
    sex: null,
    latitude: LILLE.latitude,
    longitude: LILLE.longitude,
    city: 'Lille',
    postalCode: '59000',
    avatarUrl: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

const OVERPASS_RESPONSE = {
  elements: [
    {
      type: 'node',
      id: 2,
      lat: 50.64,
      lon: 3.07,
      tags: {
        name: 'Clinique Lointaine',
        'addr:housenumber': '12',
        'addr:street': 'rue des Chats',
        'addr:postcode': '59000',
        'addr:city': 'Lille',
        phone: '+33 3 20 00 00 00',
        website: 'javascript:alert(1)',
      },
    },
    {
      type: 'way',
      id: 1,
      center: { lat: 50.63, lon: 3.058 },
      tags: { name: 'Cabinet Proche', website: 'cabinet-proche.fr' },
    },
    { type: 'node', id: 3, tags: { name: 'Sans coordonnées' } },
  ],
};

describe('VetsController', () => {
  let app: INestApplication;
  let user: User;
  let token: string;
  const fetchMock = jest.fn();

  beforeEach(async () => {
    fetchMock.mockReset();
    global.fetch = fetchMock as unknown as typeof fetch;
    user = makeUser();

    const moduleRef = await Test.createTestingModule({
      imports: [JwtModule.register({ secret: 'secret-de-test' })],
      controllers: [VetsController],
      providers: [
        VetsService,
        JwtAuthGuard,
        {
          provide: UsersService,
          useValue: {
            findById: (id: string) =>
              Promise.resolve(id === user.id ? user : null),
          },
        },
      ],
    }).compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();
    token = moduleRef.get(JwtService).sign({ sub: user.id, email: user.email });
  });

  afterEach(async () => {
    await app.close();
  });

  const get = (url: string) =>
    request(app.getHttpServer()).get(url).set('Authorization', `Bearer ${token}`);

  it('refuse sans jeton (401)', async () => {
    await request(app.getHttpServer()).get('/vets/nearby').expect(401);
  });

  it("demande de renseigner l'adresse si elle est absente (400)", async () => {
    user = makeUser({ latitude: null, longitude: null, city: null });

    const res = await get('/vets/nearby').expect(400);

    expect(res.body.message).toContain('profil');
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('refuse un rayon hors limites (400)', async () => {
    await get('/vets/nearby?radiusKm=500').expect(400);
  });

  it('renvoie les vétérinaires triés par distance, avec urls sûres (200)', async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(OVERPASS_RESPONSE),
    });

    const res = await get('/vets/nearby?radiusKm=5').expect(200);

    expect(res.body.center.city).toBe('Lille');
    expect(res.body.radiusKm).toBe(5);
    expect(res.body.vets.map((v: { name: string }) => v.name)).toEqual([
      'Cabinet Proche',
      'Clinique Lointaine',
    ]);
    expect(res.body.vets[0].website).toBe('https://cabinet-proche.fr/');
    expect(res.body.vets[1].website).toBeNull();
    expect(res.body.vets[1].address).toBe('12 rue des Chats, 59000 Lille');
    expect(res.body.vets[1].phone).toBe('+33 3 20 00 00 00');
    expect(String(fetchMock.mock.calls[0][1].body)).toContain('around%3A5000');
  });

  it('met les résultats en cache pour une même recherche', async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(OVERPASS_RESPONSE),
    });

    await get('/vets/nearby').expect(200);
    await get('/vets/nearby').expect(200);

    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('répond 503 si le service cartographique est indisponible', async () => {
    fetchMock.mockResolvedValue({ ok: false });

    await get('/vets/nearby').expect(503);
  });
});

describe('distanceKm', () => {
  it('calcule la distance Lille – Paris (~204 km)', () => {
    const d = distanceKm(50.6292, 3.0573, 48.8566, 2.3522);
    expect(d).toBeGreaterThan(200);
    expect(d).toBeLessThan(210);
  });

  it('vaut 0 pour un même point', () => {
    expect(distanceKm(50, 3, 50, 3)).toBe(0);
  });
});
