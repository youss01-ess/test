import { Type } from 'class-transformer';
import { IsInt, IsOptional, Max, Min } from 'class-validator';

export const DEFAULT_RADIUS_KM = 10;
export const MAX_RADIUS_KM = 30;

export class NearbyVetsQueryDto {
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(MAX_RADIUS_KM)
  radiusKm?: number;
}
