import { Controller, Get, Query, Req, UseGuards } from '@nestjs/common';
import { AuthenticatedRequest, JwtAuthGuard } from '../auth/jwt-auth.guard';
import { NearbyVetsQueryDto } from './dto/nearby-vets-query.dto';
import { NearbyVetsResponse, VetsService } from './vets.service';

@Controller('vets')
@UseGuards(JwtAuthGuard)
export class VetsController {
  constructor(private readonly vetsService: VetsService) {}

  @Get('nearby')
  nearby(
    @Req() req: AuthenticatedRequest,
    @Query() query: NearbyVetsQueryDto,
  ): Promise<NearbyVetsResponse> {
    return this.vetsService.findNearby(req.user.sub, query.radiusKm);
  }
}
