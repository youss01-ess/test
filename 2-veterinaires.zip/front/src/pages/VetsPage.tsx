import { lazy, Suspense, useEffect, useState } from 'react';
import { Link } from 'react-router';
import Alert from '../components/Alert';
import Button from '../components/Button';
import Card from '../components/Card';
import Layout from '../components/Layout';
import { getNearbyVets, type NearbyVets, type Vet } from '../services/api';

// Leaflet est chargé à la demande : il pèse lourd et n'est utile que sur cette page.
const VetsMap = lazy(() => import('../components/VetsMap'));

const RADIUS_OPTIONS = [5, 10, 20, 30];

function itineraryUrl(vet: Vet): string {
  return `https://www.openstreetmap.org/directions?to=${vet.latitude}%2C${vet.longitude}`;
}

function VetCard({
  vet,
  selected,
  onSelect,
}: {
  vet: Vet;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <Card
      className={`p-4 transition ${selected ? 'border-emerald-400 ring-2 ring-emerald-200' : ''}`}
    >
      <button
        className="w-full cursor-pointer text-left"
        onClick={onSelect}
        type="button"
      >
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-bold text-slate-900">{vet.name}</h3>
          <span className="shrink-0 rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-semibold text-emerald-800">
            {vet.distanceKm.toLocaleString('fr-FR')} km
          </span>
        </div>
        {vet.address && (
          <p className="mt-1 text-sm text-slate-600">{vet.address}</p>
        )}
      </button>

      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm font-semibold">
        {vet.phone && (
          <a
            className="text-emerald-700 hover:text-emerald-800"
            href={`tel:${vet.phone.replace(/[^+\d]/g, '')}`}
          >
            📞 {vet.phone}
          </a>
        )}
        {vet.website && (
          <a
            className="text-emerald-700 hover:text-emerald-800"
            href={vet.website}
            rel="noopener noreferrer"
            target="_blank"
          >
            🌐 Site web
          </a>
        )}
        <a
          className="text-emerald-700 hover:text-emerald-800"
          href={itineraryUrl(vet)}
          rel="noopener noreferrer"
          target="_blank"
        >
          🧭 Itinéraire
        </a>
      </div>
    </Card>
  );
}

export default function VetsPage() {
  const [radiusKm, setRadiusKm] = useState(10);
  const [data, setData] = useState<NearbyVets | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [needsAddress, setNeedsAddress] = useState(false);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    setNeedsAddress(false);

    getNearbyVets(radiusKm)
      .then((result) => {
        if (!cancelled) setData(result);
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setData(null);
        const message =
          err instanceof Error ? err.message : 'Une erreur est survenue';
        // L'API répond 400 tant que le profil n'a pas d'adresse.
        if (err instanceof Error && 'status' in err && err.status === 400) {
          setNeedsAddress(true);
        } else {
          setError(message);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [radiusKm]);

  return (
    <Layout>
      <main className="mx-auto max-w-7xl px-5 py-12 sm:px-8 lg:py-16">
        <p className="text-sm font-semibold uppercase tracking-wide text-emerald-700">
          Autour de vous
        </p>
        <h1 className="mt-2 text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">
          Vétérinaires proches
        </h1>
        <p className="mt-3 max-w-2xl text-slate-600">
          {data
            ? `Cabinets référencés autour de ${data.center.city}, du plus proche au plus éloigné.`
            : 'Retrouvez les cabinets vétérinaires proches de chez vous.'}
        </p>

        {needsAddress && (
          <Card className="mt-8 p-6 sm:p-8">
            <h2 className="text-xl font-bold text-slate-950">
              Indiquez votre ville pour commencer
            </h2>
            <p className="mt-2 max-w-xl text-sm text-slate-600">
              Pour suggérer des vétérinaires proches, nous avons besoin de votre
              ville et de votre code postal. C'est facultatif, et vous pouvez
              les supprimer à tout moment.
            </p>
            <Link className="mt-5 inline-block" to="/profile">
              <span className="inline-flex rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700">
                Renseigner ma localisation
              </span>
            </Link>
          </Card>
        )}

        {error && (
          <div className="mt-8">
            <Alert variant="error">{error}</Alert>
          </div>
        )}

        {!needsAddress && (
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <label
              className="text-sm font-semibold text-slate-800"
              htmlFor="vets-radius"
            >
              Rayon de recherche
            </label>
            <select
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200"
              id="vets-radius"
              onChange={(e) => setRadiusKm(Number(e.target.value))}
              value={radiusKm}
            >
              {RADIUS_OPTIONS.map((km) => (
                <option key={km} value={km}>
                  {km} km
                </option>
              ))}
            </select>
            {error && (
              <Button onClick={() => setRadiusKm((r) => r)} variant="outline">
                Réessayer
              </Button>
            )}
          </div>
        )}

        {loading && !needsAddress && (
          <p className="mt-8 text-slate-600">Recherche en cours…</p>
        )}

        {data && !loading && data.vets.length === 0 && (
          <Card className="mt-8 p-6">
            <p className="font-semibold text-slate-900">
              Aucun cabinet trouvé dans un rayon de {data.radiusKm} km.
            </p>
            <p className="mt-1 text-sm text-slate-600">
              Essayez d'élargir le rayon de recherche. Les données viennent
              d'OpenStreetMap et peuvent être incomplètes.
            </p>
          </Card>
        )}

        {data && data.vets.length > 0 && (
          <div className="mt-8 grid gap-6 lg:grid-cols-5">
            <div className="space-y-3 lg:col-span-2 lg:max-h-[28rem] lg:overflow-y-auto lg:pr-1">
              {data.vets.map((vet) => (
                <VetCard
                  key={vet.id}
                  onSelect={() => setSelectedId(vet.id)}
                  selected={selectedId === vet.id}
                  vet={vet}
                />
              ))}
            </div>
            <div className="lg:col-span-3">
              <Suspense
                fallback={
                  <div className="flex h-80 items-center justify-center rounded-xl bg-slate-100 text-slate-500 sm:h-[28rem]">
                    Chargement de la carte…
                  </div>
                }
              >
                <VetsMap
                  data={data}
                  onSelect={setSelectedId}
                  selectedId={selectedId}
                />
              </Suspense>
            </div>
          </div>
        )}

        {data && (
          <p className="mt-6 text-xs text-slate-500">
            Données © contributeurs OpenStreetMap. Distances à vol d'oiseau.
            Appelez le cabinet pour confirmer ses horaires, surtout en cas
            d'urgence.
          </p>
        )}
      </main>
    </Layout>
  );
}
