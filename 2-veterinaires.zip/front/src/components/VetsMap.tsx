import { useEffect } from 'react';
import 'leaflet/dist/leaflet.css';
import { latLngBounds } from 'leaflet';
import {
  CircleMarker,
  MapContainer,
  Popup,
  TileLayer,
  useMap,
} from 'react-leaflet';
import type { NearbyVets } from '../services/api';

type VetsMapProps = {
  data: NearbyVets;
  selectedId: string | null;
  onSelect: (id: string) => void;
};

/** Ajuste la vue pour montrer la position de l'utilisateur et tous les résultats. */
function FitBounds({ data }: { data: NearbyVets }) {
  const map = useMap();

  useEffect(() => {
    const points: [number, number][] = [
      [data.center.latitude, data.center.longitude],
      ...data.vets.map((vet): [number, number] => [vet.latitude, vet.longitude]),
    ];
    map.fitBounds(latLngBounds(points), { padding: [32, 32], maxZoom: 14 });
  }, [map, data]);

  return null;
}

export default function VetsMap({ data, selectedId, onSelect }: VetsMapProps) {
  return (
    <MapContainer
      center={[data.center.latitude, data.center.longitude]}
      className="h-80 w-full rounded-xl sm:h-[28rem]"
      scrollWheelZoom={false}
      zoom={12}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <FitBounds data={data} />

      <CircleMarker
        center={[data.center.latitude, data.center.longitude]}
        pathOptions={{ color: '#1d4ed8', fillColor: '#3b82f6', fillOpacity: 0.9 }}
        radius={9}
      >
        <Popup>Votre position : {data.center.city}</Popup>
      </CircleMarker>

      {data.vets.map((vet) => (
        <CircleMarker
          center={[vet.latitude, vet.longitude]}
          eventHandlers={{ click: () => onSelect(vet.id) }}
          key={vet.id}
          pathOptions={{
            color: '#047857',
            fillColor: selectedId === vet.id ? '#f59e0b' : '#10b981',
            fillOpacity: 0.9,
          }}
          radius={selectedId === vet.id ? 11 : 8}
        >
          <Popup>
            <strong>{vet.name}</strong>
            <br />
            {vet.distanceKm.toLocaleString('fr-FR')} km
          </Popup>
        </CircleMarker>
      ))}
    </MapContainer>
  );
}
